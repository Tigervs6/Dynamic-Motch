import AppKit
import QuartzCore

/// The screen "unfolding" when you open the lid (or unlock), and folding shut when it locks:
/// two dark halves swinging away from a glowing crease, like a folding phone opening.
///
/// macOS can't draw anything while the lid is shut or during the wake itself, so the unfold
/// plays the moment your desktop is visible again.
final class FoldAnimator {
    enum Direction {
        case unfold   // halves swing open, revealing the desktop
        case fold     // halves swing shut
    }

    var enabled: Bool {
        get { UserDefaults.standard.object(forKey: "foldAnimation") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "foldAnimation") }
    }

    private var window: NSWindow?
    private var lastPlayed = Date.distantPast

    /// Degrees each half swings. Flip the sign if the halves tilt the wrong way on your Mac.
    private let swing: CGFloat = 96

    func play(_ direction: Direction) {
        guard enabled, !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { return }
        guard Date().timeIntervalSince(lastPlayed) > 1.0 else { return }   // wake fires several times
        lastPlayed = Date()
        guard let screen = NSScreen.main else { return }

        dismiss()

        let panel = NSWindow(contentRect: screen.frame, styleMask: [.borderless],
                             backing: .buffered, defer: false)
        panel.level = .screenSaver
        panel.backgroundColor = .clear
        panel.isOpaque = false
        panel.hasShadow = false
        panel.ignoresMouseEvents = true          // clicks pass straight through to your desktop
        panel.collectionBehavior = [.canJoinAllSpaces, .stationary, .fullScreenAuxiliary, .ignoresCycle]

        let host = NSView(frame: CGRect(origin: .zero, size: screen.frame.size))
        host.wantsLayer = true
        host.layer?.backgroundColor = NSColor.clear.cgColor
        panel.contentView = host
        panel.setFrame(screen.frame, display: false)
        panel.orderFrontRegardless()
        window = panel

        let size = screen.frame.size
        let halfHeight = size.height / 2
        let duration: CFTimeInterval = direction == .unfold ? 0.85 : 0.55

        // Two halves, each hinged on the outer edge of the screen.
        let top = half(width: size.width, height: halfHeight, y: halfHeight, anchorTop: true)
        let bottom = half(width: size.width, height: halfHeight, y: 0, anchorTop: false)
        let crease = creaseLayer(width: size.width, y: halfHeight)
        host.layer?.addSublayer(top)
        host.layer?.addSublayer(bottom)
        host.layer?.addSublayer(crease)

        let openTop = rotated(swing)
        let openBottom = rotated(-swing)
        let closed = CATransform3DIdentity
        let timing = CAMediaTimingFunction(controlPoints: 0.22, 0.9, 0.24, 1)

        let opening = direction == .unfold
        animate(top, from: opening ? closed : openTop, to: opening ? openTop : closed,
                fadeOut: opening, duration: duration, timing: timing)
        animate(bottom, from: opening ? closed : openBottom, to: opening ? openBottom : closed,
                fadeOut: opening, duration: duration, timing: timing)
        animateCrease(crease, opening: opening, duration: duration, timing: timing)

        DispatchQueue.main.asyncAfter(deadline: .now() + duration + 0.1) { [weak self] in
            guard let self = self, self.window === panel else { return }
            if direction == .unfold {
                self.dismiss()
            } else {
                // A fold stays up: the display is about to switch off behind it. Clear it
                // after a few seconds in case the screen never does.
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in
                    if self?.window === panel { self?.dismiss() }
                }
            }
        }
    }

    func dismiss() {
        window?.orderOut(nil)
        window = nil
    }

    // MARK: - Layers

    private func half(width: CGFloat, height: CGFloat, y: CGFloat, anchorTop: Bool) -> CAGradientLayer {
        let layer = CAGradientLayer()
        layer.frame = CGRect(x: 0, y: y, width: width, height: height)
        layer.colors = [
            NSColor.black.cgColor,
            NSColor(white: 0.035, alpha: 1).cgColor,
            NSColor(white: 0.085, alpha: 1).cgColor,
        ]
        layer.locations = anchorTop ? [0, 0.7, 1] : [0, 0.3, 1]
        layer.startPoint = anchorTop ? CGPoint(x: 0.5, y: 1) : CGPoint(x: 0.5, y: 0)
        layer.endPoint = anchorTop ? CGPoint(x: 0.5, y: 0) : CGPoint(x: 0.5, y: 1)
        layer.isOpaque = false

        // Hinge on the screen's outer edge (layer coordinates are y-up here).
        let frame = layer.frame
        layer.anchorPoint = CGPoint(x: 0.5, y: anchorTop ? 1 : 0)
        layer.frame = frame
        return layer
    }

    private func creaseLayer(width: CGFloat, y: CGFloat) -> CAGradientLayer {
        let layer = CAGradientLayer()
        layer.frame = CGRect(x: 0, y: y - 1, width: width, height: 2)
        layer.colors = [
            NSColor.clear.cgColor,
            NSColor(white: 1, alpha: 0.75).cgColor,
            NSColor.clear.cgColor,
        ]
        layer.locations = [0, 0.5, 1]
        layer.startPoint = CGPoint(x: 0, y: 0.5)
        layer.endPoint = CGPoint(x: 1, y: 0.5)
        return layer
    }

    private func rotated(_ degrees: CGFloat) -> CATransform3D {
        var t = CATransform3DIdentity
        t.m34 = -1 / 900                      // perspective, so the halves tilt in 3D
        return CATransform3DRotate(t, degrees * .pi / 180, 1, 0, 0)
    }

    private func animate(_ layer: CALayer, from: CATransform3D, to: CATransform3D,
                         fadeOut: Bool, duration: CFTimeInterval, timing: CAMediaTimingFunction) {
        layer.transform = to
        layer.opacity = fadeOut ? 0 : 1

        let move = CABasicAnimation(keyPath: "transform")
        move.fromValue = NSValue(caTransform3D: from)
        move.toValue = NSValue(caTransform3D: to)
        move.duration = duration
        move.timingFunction = timing

        let fade = CABasicAnimation(keyPath: "opacity")
        fade.fromValue = fadeOut ? 1 : 0
        fade.toValue = fadeOut ? 0 : 1
        fade.duration = duration * (fadeOut ? 0.75 : 0.45)
        fade.beginTime = CACurrentMediaTime() + (fadeOut ? duration * 0.25 : 0)
        fade.fillMode = .backwards
        fade.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)

        layer.add(move, forKey: "fold.transform")
        layer.add(fade, forKey: "fold.opacity")
    }

    private func animateCrease(_ layer: CALayer, opening: Bool, duration: CFTimeInterval,
                               timing: CAMediaTimingFunction) {
        layer.opacity = opening ? 0 : 0.9
        let fade = CABasicAnimation(keyPath: "opacity")
        fade.fromValue = opening ? 0.9 : 0
        fade.toValue = opening ? 0 : 0.9
        fade.duration = duration * 0.7
        fade.timingFunction = timing

        let stretch = CABasicAnimation(keyPath: "transform.scale.x")
        stretch.fromValue = opening ? 0.4 : 1.0
        stretch.toValue = opening ? 1.0 : 0.4
        stretch.duration = duration
        stretch.timingFunction = timing

        layer.add(fade, forKey: "crease.opacity")
        layer.add(stretch, forKey: "crease.scale")
    }
}
